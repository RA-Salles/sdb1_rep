-- -------- < aula4exer6evolucao2 > --------
--
--                    SCRIPT DE DESTRUIÇÃO
--
-- Data Criacao ...........: 06/05/2024
-- Autor(es) ..............: Ryan Salles
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: Detran
--
-- 
-- Ultimas Alteracoes
--  Adiciona destruição da database
--
-- ---------------------------------------------------------

DROP DATABASE Detran;