what is this?
	this is where i keep stored any kind of documentation used and needed
	and where i use very very vulgar language to explain how a problem was solved
		or how it went unsolved and i just said "fuckit, it will stay just like
		that".
	Very fun.

	IF YOU WISH TO UNDERSTAND HOW TO OPERATE THIS PIECE OF SHIT SOFTWARE, GO TO "LEIAME.txt".
	THIS RIGHT HERE IS AN EXTENSION OF INLINE COMMENTS AND SERVES AS A RECORDING OF MY 
	PROCESS OF THOUGHT.
	

0159-200324
	well, deadline is tomorrow, i simply went ahead and documented the expected results.
	very fucking shameful i will need a refresher and got little to no time to refresh.
	Crashing muh car was not very fun, i must say. its costing me tons.
	oh husbando, you crash caru intu neighboru. Now we're homeress.

1320-200324
	Went ahead and coded a simple menu. works with pointers awreetus awrightus.

1550-20032024
	Started the W O R K S. Thing is, people will prolly be stored in a vector with people pointers.
	cars should be like:
	
	person1 - car1, car2, car3, etc..
	person2 - car1, etc...
	etc...

	which means a car will be organized inside a car ***cars vector, which makes me want to kill someone right now :)

2101-20032024
	According to brazilian laws, specially after the releasing of the crlv, 
	only oficial identity and crv from car is needed to perform a transference and,
	therefore, own a car. Using DETRAN's database, you can get other info with just
	the crv, meaning we'll need only that

1137-21032024
	As there's little to no time left to code and design this project, I will proceed to carry on with 
	deliverance of the code. very very fun.
	